#include "../includes/cub3d.h"
#include "../includes/rendering.h"

// Helper: put pixel directly to image buffer
static void	put_pixel_minimap(t_data *data, int x, int y, int color)
{
	char	*dst;

	if (x < 0 || x >= WIN_WIDTH || y < 0 || y >= WIN_HEIGHT)
		return ;
	dst = data->img.addr + (y * data->img.line_length + x * (data->img.bits_per_pixel / 8));
	*(unsigned int *)dst = color;
}

// Draw a simple minimap to visualize the parsed map
void	draw_minimap(t_data *data)
{
	int	scale;
	int	map_x;
	int	map_y;
	int	screen_x;
	int	screen_y;
	int	color;
	int	offset_x;
	int	offset_y;

	scale = 10; // Each map cell is 10x10 pixels
	offset_x = WIN_WIDTH - (data->map.width * scale) - 20; // Top-right corner
	offset_y = 20;
	
	map_y = 0;
	while (map_y < data->map.height)
	{
		map_x = 0;
		while (map_x < data->map.width)
		{
			// Determine color based on cell type
			if (data->map.grid[map_y][map_x] == '1')
				color = 0xFFFFFF; // White for walls
			else if (data->map.grid[map_y][map_x] == '0')
				color = 0x333333; // Dark gray for floor
			else
				color = 0x000000; // Black for space
			// Draw cell
			screen_y = 0;
			while (screen_y < scale)
			{
				screen_x = 0;
				while (screen_x < scale)
				{
					put_pixel_minimap(data, offset_x + map_x * scale + screen_x, 
							 offset_y + map_y * scale + screen_y, color);
					screen_x++;
				}
				screen_y++;
			}
			map_x++;
		}
		map_y++;
	}
	// Draw player position (red dot)
	screen_x = offset_x + (int)(data->player.x * scale);
	screen_y = offset_y + (int)(data->player.y * scale);
	int dot_size = 3;
	int dy = -dot_size;
	while (dy <= dot_size)
	{
		int dx = -dot_size;
		while (dx <= dot_size)
		{
			put_pixel_minimap(data, screen_x + dx, screen_y + dy, 0xFF0000);
			dx++;
		}
		dy++;
	}
	// Draw player direction (yellow line)
	int dir_length = 15;
	int i = 0;
	while (i < dir_length)
	{
		int line_x = screen_x + (int)(data->player.dir_x * i);
		int line_y = screen_y + (int)(data->player.dir_y * i);
		put_pixel_minimap(data, line_x, line_y, 0xFFFF00);
		i++;
	}
}

// Print parsed configuration to console for verification
void	debug_print_config(t_data *data)
{
	printf("\n========== PARSED CONFIGURATION ==========\n");
	printf("Textures:\n");
	printf("  North:  %s\n", data->textures.north);
	printf("  South:  %s\n", data->textures.south);
	printf("  West:   %s\n", data->textures.west);
	printf("  East:   %s\n", data->textures.east);
	printf("\nColors:\n");
	printf("  Floor:   RGB(%d, %d, %d)\n", 
		   data->floor.r, data->floor.g, data->floor.b);
	printf("  Ceiling: RGB(%d, %d, %d)\n", 
		   data->ceiling.r, data->ceiling.g, data->ceiling.b);
	printf("\nMap:\n");
	printf("  Size:    %d x %d\n", data->map.width, data->map.height);
	printf("  Grid:\n");
	int y = 0;
	while (y < data->map.height)
	{
		printf("    [%s]\n", data->map.grid[y]);
		y++;
	}
	printf("\nPlayer:\n");
	printf("  Position:  (%.2f, %.2f)\n", data->player.x, data->player.y);
	printf("  Direction: (%.2f, %.2f)\n", data->player.dir_x, data->player.dir_y);
	printf("  Plane:     (%.2f, %.2f)\n", data->player.plane_x, data->player.plane_y);
	printf("==========================================\n\n");
}
