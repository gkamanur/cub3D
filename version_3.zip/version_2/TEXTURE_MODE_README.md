# Ceiling and Floor Texture Support

## Overview
This Cub3D implementation now supports **both solid colors AND XPM textures** for ceiling and floor rendering, with a runtime toggle feature.

## Configuration File Format

### Required Elements
```
NO <path_to_north_wall_texture.xpm>
SO <path_to_south_wall_texture.xpm>
WE <path_to_west_wall_texture.xpm>
EA <path_to_east_wall_texture.xpm>
F <R,G,B>    # Floor color (0-255 for each channel)
C <R,G,B>    # Ceiling color (0-255 for each channel)
```

### Optional Elements (NEW!)
```
FT <path_to_floor_texture.xpm>    # Optional floor texture
CT <path_to_ceiling_texture.xpm>  # Optional ceiling texture
```

## Example Configuration

### With Textures:
```
NO ./textures/stone_wall_design/wall.xpm
SO ./textures/stone_wall_design/wall.xpm
WE ./textures/stone_wall_design/wall.xpm
EA ./textures/stone_wall_design/wall.xpm

F 139,69,19
C 205,133,63
FT ./textures/brick_wall/south.xpm
CT ./textures/brick_wall/north.xpm

1111111111
1000000001
1000N00001
1000000001
1111111111
```

### Without Textures (Classic Mode):
```
NO ./textures/stone_wall_design/wall.xpm
SO ./textures/stone_wall_design/wall.xpm
WE ./textures/stone_wall_design/wall.xpm
EA ./textures/stone_wall_design/wall.xpm

F 139,69,19
C 205,133,63

1111111111
1000000001
1000N00001
1000000001
1111111111
```

## Controls

| Key | Action |
|-----|--------|
| **W** | Move forward |
| **S** | Move backward |
| **A** | Strafe left |
| **D** | Strafe right |
| **←/→** | Rotate view |
| **T** | **Toggle between texture and color modes** |
| **ESC** | Exit program |

## Features

### 1. Dual Mode Rendering
- **Color Mode**: Uses the RGB values specified by `F` and `C` lines
- **Texture Mode**: Uses XPM textures specified by `FT` and `CT` lines (if provided)
- Toggle between modes at runtime using the **T** key

### 2. Fallback Behavior
- If `FT` or `CT` are not specified, the program uses colors even in texture mode
- Colors (`F` and `C`) are always required for fallback

### 3. Real-time Minimap
- Displays in the top-right corner
- Shows map layout, player position (red dot), and direction (yellow line)
- Updates synchronously with player movement

## Implementation Details

### Data Structure Changes
```c
typedef struct s_textures
{
    // Wall textures (required)
    char    *north, *south, *west, *east;
    t_img   north_img, south_img, west_img, east_img;
    
    // Floor/ceiling textures (optional)
    char    *floor_tex, *ceiling_tex;
    t_img   floor_img, ceiling_img;
} t_textures;

typedef struct s_data
{
    ...
    int     use_floor_texture;    // 1 if FT specified, 0 otherwise
    int     use_ceiling_texture;  // 1 if CT specified, 0 otherwise  
    int     texture_mode;         // Toggle flag (1 = textures, 0 = colors)
    ...
} t_data;
```

### Rendering Modes

#### Color Mode (Fast)
- Uses optimized memory fill (4 pixels at a time)
- Solid color for entire ceiling/floor
- Very high performance

#### Texture Mode
- Applies XPM texture mapping to ceiling and floor
- Textures are stretched to cover the entire surface
- Slightly lower performance due to per-pixel texture sampling

## Test Files

- `maps/minimal.cub` - Simple 3x3 test map
- `maps/test_textures.cub` - Map with ceiling/floor textures enabled
- `maps/test.cub` - Original test map (colors only)

## Usage

```bash
# Compile
make

# Run with texture-enabled map
./cub3D maps/test_textures.cub

# Once running, press 'T' to toggle between texture and color modes
```

## Performance Notes

- **Color mode**: ~60 FPS (optimized bulk fill)
- **Texture mode**: ~45-55 FPS (depends on texture size and complexity)
- Toggle dynamically to find the best visual/performance balance

## Future Enhancements

Possible improvements:
- Perspective-correct texture mapping for floor/ceiling
- Multiple texture layers
- Animated textures
- Texture filtering/mipmapping
